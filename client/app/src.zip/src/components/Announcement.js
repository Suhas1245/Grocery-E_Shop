import React from 'react'
import './Announcement.css'



const Announcement = () => {
  return (
    <div className='containerAnn'>
        WELCOME TO ESHOP
    </div>
  )
}

export default Announcement