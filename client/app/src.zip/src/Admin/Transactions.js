import React from 'react'

const Transactions = () => {
  return (
    <div>Transactions</div>
  )
}

export default Transactions